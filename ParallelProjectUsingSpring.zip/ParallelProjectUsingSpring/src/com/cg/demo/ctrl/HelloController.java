package com.cg.demo.ctrl;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.annotation.ModelAndViewResolver;

import com.cg.demo.dto.Customer;

import com.cg.demo.service.CustomerService;



@Controller
@RequestMapping("/helloCtrl")
public class HelloController 

{
	

	@Autowired
	CustomerService logSer=null;

	public CustomerService getLogSer() {
		return logSer;
	}
	public void setLogSer(CustomerService logSer) {
		this.logSer = logSer;
	}
	
	/*****************************************/
	
	
	@RequestMapping(value="/ShowHomepage")
	public String dispHomePage(Model model)
	{
//		String today="Today is: "+LocalDate.now();
//		model.addAttribute("todayObj",today);
		return "Home";
		
	}
	
	/*********************************************/
	@RequestMapping(value="/AddCustomer")
	public String addCust(Model model)
	{
//		Customer cus=new Customer();
//		
//		model.addAttribute("cuslist",cus);
		
		return "disp1";
		
	}
	@RequestMapping(value="/InsertCusDetails")
	public String addCustAfterJsp(@ModelAttribute("cuslist")Customer cus,Model model) 
	{
		
		model.addAttribute("cusdataobj",cus);
		logSer.AddCustomer(cus);
		return "disp1";
		
		
	}
	
}
