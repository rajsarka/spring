package com.cg.demo.bean;

import java.beans.PropertyEditor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.config.CustomEditorConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
public class SpringConfig 
{
	
	@Bean
	public ArrayList<String> getDepts() 
	{
		ArrayList<String> depList=new ArrayList<String>();
		depList.add("Java");
		depList.add("Oracle");
		depList.add("Testing");
		return depList;
	}
	
	
	/************************/
	@Bean
	public static PropertySourcesPlaceholderConfigurer
	propertyConfigDev()
	{
		return new PropertySourcesPlaceholderConfigurer();
		
	}
	/************************/
	@Bean
	public CustomEditorConfigurer customEditorConfig1()
	{
		
		Map<Class<?>,Class<? extends PropertyEditor>> customMap=new HashMap<Class<?>,Class<? extends PropertyEditor>>(1);
		
		customMap.put(java.time.LocalDate.class,MyDateEditor.class);
		
		CustomEditorConfigurer config=new CustomEditorConfigurer();
		config.setCustomEditors(customMap);
		return config;
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
}
