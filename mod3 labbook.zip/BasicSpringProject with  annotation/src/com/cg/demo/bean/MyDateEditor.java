package com.cg.demo.bean;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;

public class MyDateEditor extends PropertyEditorSupport 
{
	public MyDateEditor() {}
	public void setAsText(String text) {
		if(text.equalsIgnoreCase("getDOJ()"))
		{
//			LocalDate doj=LocalDate.of(2014, 04,03 );
//			setValue(doj);
			LocalDate doj=LocalDate.now();
			setValue(doj);
		}
	}
public String getAsText()
{
	return getValue().toString();
}
		
		
	}

