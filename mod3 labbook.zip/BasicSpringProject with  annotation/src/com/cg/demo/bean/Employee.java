package com.cg.demo.bean;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
@Component("emp1")
public class Employee {

	@Value("178198")
	private int empId;
	
	@Value("Rajib Sarkar")
	private String empName;
	
	@Value("20000")
	private float empSal;
	
	@Resource(name="getDepts")
	private ArrayList<String> depts;
	
	@Autowired
	private Address empAdd;
	
	@Value("getDOJ()")
	private LocalDate empDOJ;
	
	public LocalDate getEmpDOJ() {
		return empDOJ;
	}
	public void setEmpDOJ(LocalDate empDOJ) {
		this.empDOJ = empDOJ;
	}
	public ArrayList<String> getDepts() {
		return depts;
	}
	public void setDepts(ArrayList<String> depts) {
		this.depts = depts;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	
	
	public Address getEmpAdd() {
		return empAdd;
	}
	public void setEmpAdd(Address empAdd) {
		this.empAdd = empAdd;
	}
	public Employee() {
		
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", depts=" + depts
				+ ", empAdd=" + empAdd + ", empDOJ=" + empDOJ + "]";
	}
	
	
}
