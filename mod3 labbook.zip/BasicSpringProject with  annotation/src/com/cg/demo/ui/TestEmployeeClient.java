package com.cg.demo.ui;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.demo.bean.Employee;

@ComponentScan(basePackages="com.cg.demo.bean")
public class TestEmployeeClient {
	
	public static void main(String[] args) 
	
{
	
		ApplicationContext ctx= SpringApplication.run(TestEmployeeClient.class,args);
		Employee e1=(Employee) ctx.getBean("emp1");
		System.out.println(e1);
		
}
}
