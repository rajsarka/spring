package com.cg.demo.bean;
public interface IGreet 
{
	public String greetMe();
}
