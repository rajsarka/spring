
package com.cg.demo.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("gt1")
public class BirthDayWishImpl implements IGreet 
{
	@Value("Rajib")
	String name;
	
	@Value("2010")
	int year;
	
	
	
	//setter injection
	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("In set name  : ");
		this.name = name;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		System.out.println("In set year  : ");
		this.year = year;
	}

	
	
	public BirthDayWishImpl() {
		System.out.println("In BirthDayWishImpl default constructor : ");
	}

	//constructor injection
	public BirthDayWishImpl(String name, int year) {
		super();
		System.out.println("In BirthDayWishImpl parametr constructor : ");
	
		this.name = name;
		this.year = year;
	}

	@Override
	public String greetMe() {
		
		return "Happy Birthday: "+name+" in "+year;
	}

	public void setUp()
	{
		System.out.println("In set up of Birthday wish : ");
	
	}
	
	public void tearDown()
	{
		System.out.println("In tearDown of Birthday wish : ");
	
	}
}
