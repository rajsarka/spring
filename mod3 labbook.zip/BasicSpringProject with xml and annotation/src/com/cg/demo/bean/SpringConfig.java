package com.cg.demo.bean;

import java.util.ArrayList;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig 
{
	
	@Bean
	public ArrayList<String> getDepts() 
	{
		ArrayList<String> depList=new ArrayList<String>();
		depList.add("Java");
		depList.add("Oracle");
		depList.add("Testing");
		return depList;
	}
	
}
