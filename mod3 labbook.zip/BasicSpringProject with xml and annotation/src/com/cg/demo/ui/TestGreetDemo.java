package com.cg.demo.ui;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.web.context.support.XmlWebApplicationContext;

import com.cg.demo.bean.IGreet;

public class TestGreetDemo {
public static void main(String[] args) {
	
	
	

	
	
	//Using ApplicationContext container
	ApplicationContext ctx= new  ClassPathXmlApplicationContext("cg.xml");
	IGreet obj1=(IGreet) ctx.getBean("gt1");
	System.out.println(obj1.greetMe());
	
	

	
	IGreet obj2=(IGreet) ctx.getBean("newYearWishImpl");
	System.out.println(obj2.greetMe());
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
}
