package com.cg.demo.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.demo.bean.Employee;
import com.cg.demo.bean.IGreet;

public class TestEmployeeClient {
	
	public static void main(String[] args) {
	//Using ApplicationContext container
		ApplicationContext ctx= new  ClassPathXmlApplicationContext("cg.xml");
		Employee e1=(Employee) ctx.getBean("emp1");
		System.out.println(e1);
		Employee e2=(Employee) ctx.getBean("emp2");
		System.out.println(e2);
}
}
