package com.cg.demo.bean;

public class BirthDayWishImpl implements IGreet {

	String name;
	int year;
	
	
	
	//setter injection
	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("In set name  : ");
		this.name = name;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		System.out.println("In set year  : ");
		this.year = year;
	}

	
	
	public BirthDayWishImpl() {
		System.out.println("In BirthDayWishImpl constructor : ");
	}

	//constructor injection
	public BirthDayWishImpl(String name, int year) {
		super();
		System.out.println("In BirthDayWishImpl parametr constructor : ");
	
		this.name = name;
		this.year = year;
	}

	@Override
	public String greetMe() {
		
		return "Happy Birthday: "+name+" in "+year;
	}

	public void setUp()
	{
		System.out.println("In set up of Birthday wish : ");
	
	}
	
	public void tearDown()
	{
		System.out.println("In tearDown of Birthday wish : ");
	
	}
}
