package com.cg.demo.bean;

import java.time.LocalDate;
import java.util.ArrayList;

public class Employee {

	
	private int empId;
	private String empName;
	private float empSal;
	private ArrayList<String> depts;
	private Address empAdd;
	private LocalDate empDOJ;
	
	public LocalDate getEmpDOJ() {
		return empDOJ;
	}
	public void setEmpDOJ(LocalDate empDOJ) {
		this.empDOJ = empDOJ;
	}
	public ArrayList<String> getDepts() {
		return depts;
	}
	public void setDepts(ArrayList<String> depts) {
		this.depts = depts;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	
	
	public Address getEmpAdd() {
		return empAdd;
	}
	public void setEmpAdd(Address empAdd) {
		this.empAdd = empAdd;
	}
	public Employee() {
		
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", depts=" + depts
				+ ", empAdd=" + empAdd + ", empDOJ=" + empDOJ + "]";
	}
	
	
}
