package com.cg.demo.dao;

import java.util.ArrayList;


import com.cg.demo.dto.Qmaster;

public interface ILoginDao 
{

	public Qmaster fetchDet(int id);	
}
