package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.cg.demo.dto.Qmaster;


@Repository
@Transactional
public class LoginDaoImpl implements ILoginDao
{
	
	
	@PersistenceContext
	EntityManager entitymgr=null;

	public EntityManager getEntitymgr() {
		return entitymgr;
	}
	public void setEntitymgr(EntityManager entitymgr) {
		this.entitymgr = entitymgr;
	}
	public Qmaster fetchDet(int id) {
		
		Qmaster obj=entitymgr.find(Qmaster.class, id);
		return obj;
	}
	
}
