package com.cg.demo.service;

import java.util.ArrayList;


import com.cg.demo.dto.Qmaster;

public interface ILoginService 
{
	public Qmaster fetchDet(int id);
	
	
}
