package com.cg.demo.service;

import java.util.ArrayList;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.demo.dao.ILoginDao;

import com.cg.demo.dto.Qmaster;

@Service
@Transactional
public class LoginServiceImpl implements ILoginService 
{
	@Autowired
	ILoginDao loginDao=null;
	
	public ILoginDao getLoginDao()
	{
		return loginDao;
	}
	public void setLoginDao(ILoginDao loginDao)
	{
		this.loginDao=loginDao;
	}
	public Qmaster fetchDet(int id) {
		return loginDao.fetchDet(id);
	}

}
