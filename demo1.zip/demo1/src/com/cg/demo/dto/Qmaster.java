package com.cg.demo.dto;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="query_master")
public class Qmaster 
{
	@Id
	@Column(name="query_id")
	private int queryId;
	@Column(name="technology")
	private String tech;
	@Column(name="query_raised_by")
	private String queryperson;
	@Column(name="query")
	private String querydata;
	@Column(name="solutions")
	private String querysol;
	@Column(name="solution_given_by")
	private String solby;
	public int getQueryId() {
		return queryId;
	}
	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech = tech;
	}
	public String getQueryperson() {
		return queryperson;
	}
	public void setQueryperson(String queryperson) {
		this.queryperson = queryperson;
	}
	public String getQuerydata() {
		return querydata;
	}
	public void setQuerydata(String querydata) {
		this.querydata = querydata;
	}
	public String getQuerysol() {
		return querysol;
	}
	public void setQuerysol(String querysol) {
		this.querysol = querysol;
	}
	public String getSolby() {
		return solby;
	}
	public void setSolby(String solby) {
		this.solby = solby;
	}
	@Override
	public String toString() {
		return "Qmaster [queryId=" + queryId + ", tech=" + tech + ", queryperson=" + queryperson + ", querydata="
				+ querydata + ", querysol=" + querysol + ", solby=" + solby + "]";
	}
	public Qmaster(int queryId, String tech, String queryperson, String querydata, String querysol, String solby) {
		super();
		this.queryId = queryId;
		this.tech = tech;
		this.queryperson = queryperson;
		this.querydata = querydata;
		this.querysol = querysol;
		this.solby = solby;
	}
	public Qmaster() {
		
	}


	
	
	
	
	
	
}
