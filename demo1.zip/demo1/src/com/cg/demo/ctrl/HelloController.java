package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.annotation.ModelAndViewResolver;

import com.cg.demo.dto.Qmaster;

import com.cg.demo.service.ILoginService;

@Controller
@RequestMapping("/helloCtrl")
public class HelloController 

{
	@Autowired
	ILoginService logSer=null;
	
	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}
	
	
	@RequestMapping(value="/ShowGearpage")
	public String dispHomePage(Model model)
	{
		Qmaster qm=new Qmaster();
		model.addAttribute("qmfstObj",qm);
		return "GearfstPage";
		
	}
	
	@RequestMapping(value="/gtformpage")
	public String dispSecPage(@ModelAttribute("qmfstObj")Qmaster trn,Model model)
	{
		Qmaster trg=logSer.fetchDet(trn.getQueryId());
	
	
		model.addAttribute("qmfstObj",trg);
		return "gtmainpage";
		}
		
		
	}
	
	

