package com.cg.demo.ctrl;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Register;
import com.cg.demo.service.ILoginService;


@Controller
public class LoginController {

	@Autowired
	ILoginService logSer=null;
	
	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}
	
	
	/******************/
	
	
	@RequestMapping(value="/LogInPage" ,method=RequestMethod.GET)
	public String showLoginPage(Model model)
	{	
		
		Login lg=new Login();
		String msg="Today is : "+LocalDate.now();
		model.addAttribute("msgobj",msg);
		model.addAttribute("loginobj",lg);  //model attribute "loginobj" name must be in modelattribute on LogIn.jsp
		return "LogIn";  //returning to LogIn.jsp
		
	}
	
	/******************/
	
	
	
	
	@RequestMapping(value="/validtaeUser",method=RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginobj")@Valid Login lgg,BindingResult result,Model model) 
{
if(result.hasErrors())
{
	System.out.println("Errors...!!!");
	return "LogIn";
}
	
else 
	{
			
		
		Login user=logSer.validtaeUser(lgg);
		if(user!=null)
		{	
			if(user.getPassword().equalsIgnoreCase(lgg.getPassword()))
			{
				String msg="Welcome u r valid user"+user.getUsername();
				model.addAttribute("MsgObj",msg);
				return "Success";
			}
			
			else
			{
				String msg="Sorry Invalid Password";
				model.addAttribute("MsgObj",msg);
				return "LogIn";
				
				
			}
			
		}
		else
		{	
			Register reg=new Register();
			model.addAttribute("userObj",reg);
			
			ArrayList<String> cityList=new ArrayList<String>();
			cityList.add("Pune");
			cityList.add("Kolkata");
			cityList.add("Delhi");
			cityList.add("Mumbai");
			model.addAttribute("cList",cityList);
			
			ArrayList<String> skills=new ArrayList<String>();
			skills.add("Java");
			skills.add("BI");
			skills.add("ORACLE");
			skills.add("HTML");
			model.addAttribute("skillList",skills);
			
			
			return "Register";
		
		}
	
		
	}
}	
	


	/*********************************/
	
	@RequestMapping(value="InsertUserDetails")
	public String addUser(@ModelAttribute("userObj")@Valid Register reg,Model model,BindingResult result) {
		
		String sMsg="Data is inserted Successfully";
		String eMsg="Error in insertion";

		Register rg=logSer.addUserDetails(reg);
		Login lg=logSer.addUser(new Login(reg.getUname(),reg.getPwd()));
		
		if(rg!=null && lg!=null)
		{
			
			model.addAttribute("MsgObj",sMsg);
		}
		
		else
		{
			model.addAttribute("MsgObj",eMsg);
		}
		
		
		
		return "redirect:ShowAllUserDetails.obj";
		
		
	}
	
	/******************/
	@RequestMapping(value="/DeleteUser")
	public String delUser(@RequestParam("unm")String name)
	{
		
		logSer.delUser(name);
		return "redirect:ShowAllUserDetails.obj";
		
		
	}
	/**************************************/
	
	@RequestMapping(value="/ShowAllUserDetails")
	public String dispAllUserDetails(Model model)
	{
		ArrayList<Register> uList=logSer.fetchAllUser();
		model.addAttribute("UserListObj",uList);
		return "ListAllUser";
		
		
	}
	
	
}
