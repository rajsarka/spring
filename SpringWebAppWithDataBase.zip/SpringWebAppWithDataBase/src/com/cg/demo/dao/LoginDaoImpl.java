package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Register;

@Repository
@Transactional
public class LoginDaoImpl implements ILoginDao
{
	
	
	@PersistenceContext
	EntityManager entitymgr=null;

	public EntityManager getEntitymgr() {
		return entitymgr;
	}
	public void setEntitymgr(EntityManager entitymgr) {
		this.entitymgr = entitymgr;
	}

	@Override
	public Login validtaeUser(Login user) 
	{
		
		Login usr =	entitymgr.find(Login.class, user.getUsername()); //retrieving data i.e user name from database
			
		return usr;
	}
	@Override
	public Register addUserDetails(Register reg) {
		entitymgr.persist(reg);
		Register obj=entitymgr.find(Register.class, reg.getUname());
		return obj;
	}
	@Override
	public Login addUser(Login log) {
		
		entitymgr.persist(log);
		Login obj=entitymgr.find(Login.class, log.getUsername());
		return obj;
	}
	@Override
	public ArrayList<Register> fetchAllUser() 
	{
		String selq="SELECT reg FROM Register reg";
		TypedQuery<Register> tq=entitymgr.createQuery(selq,Register.class);
		ArrayList<Register> uList=(ArrayList)tq.getResultList();
		
		return uList;
	}
	@Override
	public void delUser(String unm) {
		Register reg=entitymgr.find(Register.class, unm);
		Login log=entitymgr.find(Login.class,unm);
		entitymgr.remove(reg);
		entitymgr.remove(log);
		System.out.println("data deleted....");
		
	}
}
