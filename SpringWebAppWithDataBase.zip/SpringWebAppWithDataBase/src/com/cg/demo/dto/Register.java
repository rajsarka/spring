package com.cg.demo.dto;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="cg_userdetails")
public class Register 
{
	@Id
	@Column(name="user_name")
	private String uname;
	
	@Transient
	private String pwd;
	@Transient
	private String confirmPassword;
	
	@Column(name="first_name")
	private String firstName;
	@Column(name="last_name")
	private String lastName;
	@Column(name="user_city")
	private String city;
	@Transient
	private String skillSet[];
	
	@Column(name="user_email")
	private String email;
	@Column(name="user_gender")
	private char gender;
	@Column(name="user_skill")
	private String skillsetStr;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String[] getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String[] skillSet) {
		this.skillSet = skillSet;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getSkillsetStr() {
		return skillsetStr;
	}
	public void setSkillsetStr(String skillsetStr) {
		this.skillsetStr = skillsetStr;
	}
	@Override
	public String toString() {
		return "Register [uname=" + uname + ", pwd=" + pwd + ", confirmPassword=" + confirmPassword + ", firstName="
				+ firstName + ", lastName=" + lastName + ", city=" + city + ", skillSet=" + Arrays.toString(skillSet)
				+ ", email=" + email + ", gender=" + gender + ", skillsetStr=" + skillsetStr + "]";
	}
	public Register() {
		super();
		
	}
	public Register(String uname, String pwd, String confirmPassword, String firstName, String lastName, String city,
			String[] skillSet, String email, char gender, String skillsetStr) {
		super();
		this.uname = uname;
		this.pwd = pwd;
		this.confirmPassword = confirmPassword;
		this.firstName = firstName;
		this.lastName = lastName;
		this.city = city;
		this.skillSet = skillSet;
		this.email = email;
		this.gender = gender;
		this.skillsetStr = skillsetStr;
	}
	
	
	
	
	
	
}
