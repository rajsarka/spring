package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Register;

public interface ILoginService 
{
	public Login validtaeUser(Login user);
	
	public Register addUserDetails(Register reg);
	public Login addUser(Login log);
	
	public ArrayList<Register> fetchAllUser() ;
	public void delUser(String unm);
	
	
}
