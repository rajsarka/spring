package com.cg.demo.dto;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Customer_table")
public class Customer {
	@Id
	@Column(name="mob_no",length=10)
	private String mobileno;
	@Column(name="cus_name",length=20)
	private String name;
	@Column(name="aadhar_no",length=15)
	private String aadhar;
	@Column(name="bank_name",length=15)
	private String bankname;
	@Column(name="acc_no",length=15)
	private String accno;
	@Column(name="cus_amount",length=15)
	private long amount;
	@Column(name="cus_pwd",length=10)
	private String pword;
	

	

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getAccno() {
		return accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public String getPword() {
		return pword;
	}

	public void setPword(String pword) {
		this.pword = pword;
	}
	


	@Override
	public String toString() {
		return "Customer [mobileno=" + mobileno + ", name=" + name + ", aadhar=" + aadhar + ", bankname=" + bankname
				+ ", accno=" + accno + ", amount=" + amount + ", pword=" + pword + "]";
	}

	public Customer(String mobileno, String name, String aadhar, String bankname, String accno, long amount,
			String pword) {
		super();
		this.mobileno = mobileno;
		this.name = name;
		this.aadhar = aadhar;
		this.bankname = bankname;
		this.accno = accno;
		this.amount = amount;
		this.pword = pword;
	}

	public Customer() {
		
	}
	
	
	
	}
	
	
	
	
	
	


