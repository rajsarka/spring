package com.cg.demo.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;


import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.demo.dto.Customer;
import com.cg.demo.dto.Login;

import com.cg.demo.dto.Transaction;


@Repository
@Transactional
public class CustomerDAOImpl implements CustomerDAO{

	@PersistenceContext
	EntityManager entitymgr=null;

	public EntityManager getEntitymgr() {
		return entitymgr;
	}
	public void setEntitymgr(EntityManager entitymgr) {
		this.entitymgr = entitymgr;
	}

	@Override
	public Customer validtaeUser(Customer user) 
	{
		
		Customer usr =	entitymgr.find(Customer.class, user.getMobileno()); //retrieving data i.e user name from database
			
		return usr;
	}
	
	
	public Customer AddCustomer(Customer cus)  {
	
		entitymgr.persist(cus);
		Customer obj=entitymgr.find(Customer.class, cus.getMobileno());
		return obj;
	}

	@Override
	public ArrayList<Customer> getCustomerList()  {

		String selq="SELECT reg FROM Customer reg";
		TypedQuery<Customer> tq=entitymgr.createQuery(selq,Customer.class);
		ArrayList<Customer> uList=(ArrayList<Customer>)tq.getResultList();
		
		return uList;
	
	}

	@Override
	public Customer showBalance(String mobileno)  {
		
		Customer e1=entitymgr.find(Customer.class, mobileno);
		return e1;
		
	}

	@Override
	public Customer addMoney(String mobno, long amt)  {
		String tranType="Credited";
		long updatedBal=0;
		
		
		Customer cus=entitymgr.find(Customer.class, mobno);
		updatedBal=cus.getAmount()+amt;
		cus.setAmount(updatedBal);
		entitymgr.merge(cus);
		System.out.println("Balance "+amt+" is Credited for: "+mobno);
		insertTransactions(mobno, amt, tranType);
		return cus;
	}

	public void insertTransactions(String mobno, long amt, String tranType) {
		
	
		Transaction transac=new Transaction();
		transac.setMobno(mobno);
		transac.setAmount(amt);
		transac.setTrantype(tranType);
		transac.setTranDate(Date.valueOf(LocalDate.now()) );
		entitymgr.persist(transac);
		
		
		System.out.println("Data is inserted in the table");
		
	
	
	
	}
	

	public Customer withdraw(String mobno, long amt)  {
		
		String tranType="Debited";
		long updatedBal=0;
		
		Customer cus=entitymgr.find(Customer.class, mobno);
		updatedBal=cus.getAmount()-amt;
		cus.setAmount(updatedBal);
		entitymgr.merge(cus);
		System.out.println("Balance "+amt+" is Debited for: "+mobno);
		insertTransactions(mobno, amt, tranType);
		return cus;


		
	}

	@Override
	public Customer fundTransfer(String mobno1, String mobno2, long famt)  {

		addMoney(mobno2,famt);
		withdraw(mobno1, famt);	
		System.out.println("Debited Rs. "+famt+" from "+mobno1+" and credited Rs. "+famt+" to "+mobno2);
		return null;
	}
	public ArrayList<Transaction> printTransaction(String mobno) {
		
		
		Customer cus1=entitymgr.find(Customer.class, mobno);
	
	
		String myQry="SELECT tra FROM Transaction tra WHERE tra.mobno=:mobno"; 
		TypedQuery<Transaction> tyQry=entitymgr.createQuery(myQry, Transaction.class);
		tyQry.setParameter("mobno", mobno);
		ArrayList<Transaction> tranList=(ArrayList<Transaction>)tyQry.getResultList();
	
	
		
		return tranList;
		
	}

	@Override
	public Customer getMobno(String mobno)  {
		
		Customer e1=entitymgr.find(Customer.class, mobno);
		return e1;
		
	}

	

}
