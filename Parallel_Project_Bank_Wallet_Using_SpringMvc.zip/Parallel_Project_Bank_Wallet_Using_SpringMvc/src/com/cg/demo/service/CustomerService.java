package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.dto.Customer;
import com.cg.demo.dto.Login;
import com.cg.demo.dto.Transaction;




public interface CustomerService {


	

	public Customer validtaeUser(Customer user);
	
	public Customer AddCustomer(Customer cus) ;
	
	public ArrayList<Customer> getCustomerList() ;
	
	public Customer showBalance(String mobileno) ;

	public Customer addMoney(String mobno, long amt)  ;
	
	public Customer withdraw(String mobno,long  amt) ;
	
	public Customer fundTransfer(String mobno1,String mobno2,long famt) ;

	public ArrayList<Transaction> printTransaction(String mobno) ;
		
	public Customer getMobno(String mobno) ;

	

}
