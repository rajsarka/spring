package com.cg.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.demo.dao.CustomerDAO;
import com.cg.demo.dto.Customer;
import com.cg.demo.dto.Login;
import com.cg.demo.dto.Transaction;



@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDAO dao =null;
	

	
	
	public Customer AddCustomer(Customer cus) {
	return dao.AddCustomer(cus);
		
	
	}

	public ArrayList<Customer> getCustomerList()  {
		return dao.getCustomerList();
		
	}



	public Customer showBalance(String mobileno)  {
		return dao.showBalance(mobileno);
		
	}



	@Override
	public Customer addMoney(String mobno, long amt)  {
		
		
			return dao.addMoney(mobno, amt);
		
	}
	
	public Customer withdraw(String mobno,long  amt)  {
		return dao.withdraw(mobno, amt);
	}


	public Customer fundTransfer(String mobno1,String mobno2,long famt) {
		return dao.fundTransfer(mobno1, mobno2, famt);
	}

	public ArrayList<Transaction> printTransaction(String mobno){
		return dao.printTransaction(mobno);
	}

	public Customer getMobno(String mobno) {
		return dao.getMobno(mobno);
	}

	@Override
	public Customer validtaeUser(Customer user) {
		
		return dao.validtaeUser(user);
	}
	

}
