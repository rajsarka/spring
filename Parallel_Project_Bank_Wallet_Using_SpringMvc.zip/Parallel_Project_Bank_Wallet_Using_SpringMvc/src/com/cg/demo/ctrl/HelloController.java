package com.cg.demo.ctrl;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.annotation.ModelAndViewResolver;

import com.cg.demo.dto.Customer;
import com.cg.demo.dto.Login;
import com.cg.demo.dto.Transaction;
import com.cg.demo.service.CustomerService;



@Controller
@RequestMapping("/helloCtrl")
public class HelloController 

{
	

	@Autowired
	CustomerService logSer=null;

	public CustomerService getLogSer() {
		return logSer;
	}
	public void setLogSer(CustomerService logSer) {
		this.logSer = logSer;
	}
	
	/*****************************************/
	
	
	@RequestMapping(value="/ShowHomepage")
	public String dispHomePage(Model model)
	{
//		String today="Today is: "+LocalDate.now();
//		model.addAttribute("todayObj",today);
		return "Home";
		
	}
	
	/*********************************************/
	@RequestMapping(value="/AddCustomer")
	public String addCust(Model model)
	{
		Customer cus=new Customer();
		
		model.addAttribute("cuslist",cus);
		
		return "AddCust";
		
	}
	@RequestMapping(value="/InsertCusDetails",method=RequestMethod.GET)
	public String addCustAfterJsp(@ModelAttribute("cuslist")Customer cus,Model model) 
	{
		
		//model.addAttribute("cuslist",cus);
		logSer.AddCustomer(cus);
		return "disp1";
		
		
	}
	/*********************************************/
	
	@RequestMapping(value="/showCusList")
	public String showCustList(Model model) 
	{
		String st="Customer Details";
		ArrayList<Customer> cList=logSer.getCustomerList();
		model.addAttribute("CustListObj",cList);
		model.addAttribute("MsgObj",st);

		return "ListAllCust";
		
		
	}
	/*********************************************/
	
	@RequestMapping(value="/showBalance" ,method=RequestMethod.GET)
	public String showLoginPage(Model model)
	{	
		
		Customer cus=new Customer();
		String str="Login Page";
		model.addAttribute("msgobj",str);
		model.addAttribute("loginobj",cus);  //model attribute "loginobj" name must be in modelattribute on LogIn.jsp
		return "LogIn";  //returning to LogIn.jsp
		
	}
	
	@RequestMapping(value="/validtaeUser",method=RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginobj")Customer cust,Model model) {
		
		Customer user=logSer.validtaeUser(cust);
		if(user!=null)
		{	
			if(user.getPword().equalsIgnoreCase(cust.getPword()))
			{
				long amount=user.getAmount();
				String srt=("Your Account Balance is : "+amount);
				model.addAttribute("balobj",srt);
				return "Showbalance";
			}
			
			else
			{
				String msg="Sorry Invalid Password";
				model.addAttribute("MsgObj",msg);
				return "LogIn";
				
				
			}
			
		}
		else
		{
			return "redirect:AddCustomer.obj";
		
		}
	
		
	}
	
	/*********************************************/
	@RequestMapping(value="/withMoney" ,method=RequestMethod.GET)
	public String withMoney(Model model)
	{	
		
		Customer cus=new Customer();
		String str="Login Page";
		model.addAttribute("msgobj",str);
		model.addAttribute("loginobj",cus);  //model attribute "loginobj" name must be in modelattribute on LogIn.jsp
		return "LogIn2";  //returning to LogIn.jsp
		
	}
	@RequestMapping(value="/validtaeUser2",method=RequestMethod.POST)
	public String isUserValid1(@ModelAttribute("loginobj")Customer cust,Model model) {
		
		Customer user=logSer.validtaeUser(cust);
		if(user!=null)
		{	
			if(user.getPword().equalsIgnoreCase(cust.getPword()))
			{
				Customer cus1=new Customer();
				model.addAttribute("withmon",cus1);
				return "WithMoney";
			}
			
			else
			{
				String msg="Sorry Invalid Password";
				model.addAttribute("MsgObj",msg);
				return "LogIn";
				
				
			}
			
		}
		else
		{
			return "redirect:AddCustomer.obj";
		
		}
	
		
	}
	
	@RequestMapping(value="/withoperation")
	public String withdrawOperation(@ModelAttribute("withmoney")Customer cus,Model model)
	{
		Customer cus2=logSer.withdraw(cus.getMobileno(),cus.getAmount());
	
		String msg1=(cus.getAmount()+" Rs. Debited from "+cus2.getMobileno());
		model.addAttribute("detwithlist",cus2);
		model.addAttribute("msg1obj",msg1);

		return "AfterWith";
		
	}
	/*********************************************/
	@RequestMapping(value="/depMoney" ,method=RequestMethod.GET)
	public String addMoney(Model model)
	{	
		
		Customer cus1=new Customer();
		String str="Deposite Money";
		model.addAttribute("addmony",cus1);
		model.addAttribute("msg2obj",str);
		return "AddMoney";
		
		
	}
	
	@RequestMapping(value="/addoperation")
	public String addMoneyOperation(@ModelAttribute("addmony")Customer cus,Model model)
	{
	
		Customer cus2=logSer.addMoney(cus.getMobileno(),cus.getAmount());
		String msg1=(cus.getAmount()+" Rs. credited To "+cus2.getMobileno());
		model.addAttribute("detaddlist",cus2);
		model.addAttribute("msg2obj",msg1);

		return "AfterAdd";
		
	}
	/*********************************************/
	@RequestMapping(value="/fundTransfer" ,method=RequestMethod.GET)
	public String fundTrans(Model model)
	{	
		
		Customer cus=new Customer();
		String str="Login Page";
		model.addAttribute("msgobj",str);
		model.addAttribute("loginobj",cus);  //model attribute "loginobj" name must be in modelattribute on LogIn.jsp
		return "LogIn5";  //returning to LogIn.jsp
		
	}
	
	@RequestMapping(value="/fundtransfer2",method=RequestMethod.POST)
	public String fundtrans2(@ModelAttribute("loginobj")Customer cust,Model model) {
		
		Customer user=logSer.validtaeUser(cust);
		if(user!=null)
		{	
			if(user.getPword().equalsIgnoreCase(cust.getPword()))
			{
				Customer cus=new Customer();
				String str="Fund Transafer";
				model.addAttribute("msgobj",str);
				model.addAttribute("loginobj",cus);
				return "LogIn3";
			}
			
			else
			{
				String msg="Sorry Invalid Password";
				model.addAttribute("MsgObj",msg);
				return "LogIn";
				
				
			}
			
		}
		else
		{
			return "redirect:AddCustomer.obj";
		
		}
	
		
	}
	@RequestMapping(value="/fundtrans")
	public String fundTransOperation(@ModelAttribute("loginobj")Customer cus,Model model)
	{
		
		Customer cus2=logSer.fundTransfer(cus.getMobileno(),cus.getAccno(),cus.getAmount());
		String msg1=(cus.getAmount()+" Rs. credited To "+cus.getAccno()+"& Debited from "+cus.getMobileno());
		model.addAttribute("detaddlist",cus2);
		model.addAttribute("msg2obj",msg1);
		Customer cust1=logSer.showBalance(cus.getMobileno());
		model.addAttribute("custdet1",cust1);
		Customer cust2=logSer.showBalance(cus.getAccno());
		model.addAttribute("custdet2",cust2);
		return "AfterFundTransfer";
		
	}
	/**************************************************/
	@RequestMapping(value="/printTransaction")
	public String printTransac1(Model model) 
	{
		Customer cus=new Customer();
		String str="Login Page";
		model.addAttribute("msgobj",str);
		model.addAttribute("loginobj",cus);  //model attribute "loginobj" name must be in modelattribute on LogIn.jsp
		return "LogIn4";  //returning to LogIn.jsp
		
		
	}
	@RequestMapping(value="/PrintTransac2",method=RequestMethod.POST)
	public String PrintTransaction2(@ModelAttribute("loginobj")Customer cust,Model model) {
		
		Customer user=logSer.validtaeUser(cust);
		if(user!=null)
		{	
			if(user.getPword().equalsIgnoreCase(cust.getPword()))
			{
				String st="Transaction Details";
				ArrayList<Transaction> cList1=logSer.printTransaction(user.getMobileno());
				model.addAttribute("TranListObj",cList1);
				model.addAttribute("MsgObj",st);

				return "ListAllTransaction";
			}
			
			else
			{
				String msg="Sorry Invalid Password";
				model.addAttribute("MsgObj",msg);
				return "LogIn";
				
				
			}
			
		}
		else
		{
			return "redirect:AddCustomer.obj";
		
		}
	
		
	}
	
}
