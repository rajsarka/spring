package com.cg.rajib;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
	 Foo mockedFoo = Mockito.mock(Foo.class);

     Mockito.when(someService.getFoo()).thenReturn(mockedFoo);

     Mockito.verify(otherService).doStuff(mockedFoo);
}
