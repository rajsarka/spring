package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



public class helloctrl {
	@RequestMapping(value="/LogInPage" ,method=RequestMethod.GET)
	public String showLoginPage(Model model)
	{
	
		
		return "pie";  //returning to pie.jsp
		
	}
	
}
