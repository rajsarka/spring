package com.cg.exam.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.exam.bean.HotelBooking;
import com.cg.exam.dao.IBookingDao;

@Service
//@Transactional
public class BookingServiceImpl implements IBookingService{

	@Autowired
	IBookingDao loginDao=null;
	
	
	public IBookingDao getLoginDao() {
		return loginDao;
	}


	public void setLoginDao(IBookingDao loginDao) {
		this.loginDao = loginDao;
	}



	@Override
	public ArrayList<HotelBooking> fetchHotelDetails() {
		
		return loginDao.fetchHotelDetails();
	}

}
