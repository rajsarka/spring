package com.cg.exam.service;

import java.util.ArrayList;

import com.cg.exam.bean.HotelBooking;

public interface IBookingService {

	
	public ArrayList<HotelBooking> fetchHotelDetails();

	
}
