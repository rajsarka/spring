package com.cg.exam.bean;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="hoteldetails")
public class HotelBooking {

	@Id
	@Column(name="id")
	private int hotelId;
	
	@Column(name="name")
	private String hotelName;
	
	@Column(name="rating")
	private String hotelRating;
	
	@Column(name="rate")
	private String hotelRate;
	
	@Column(name="availablerooms")
	private int hotelAvailableRooms;

	public HotelBooking() {
		super();
	}

	public HotelBooking(int hotelId, String hotelName, String hotelRating, String hotelRate, int hotelAvailableRooms) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelRating = hotelRating;
		this.hotelRate = hotelRate;
		this.hotelAvailableRooms = hotelAvailableRooms;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getHotelRating() {
		return hotelRating;
	}

	public void setHotelRating(String hotelRating) {
		this.hotelRating = hotelRating;
	}

	public String getHotelRate() {
		return hotelRate;
	}

	public void setHotelRate(String hotelRate) {
		this.hotelRate = hotelRate;
	}

	public int getHotelAvailableRooms() {
		return hotelAvailableRooms;
	}

	public void setHotelAvailableRooms(int hotelAvailableRooms) {
		this.hotelAvailableRooms = hotelAvailableRooms;
	}

	@Override
	public String toString() {
		return "HotelBooking [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelRating=" + hotelRating
				+ ", hotelRate=" + hotelRate + ", hotelAvailableRooms=" + hotelAvailableRooms + "]";
	}

	
	
}
