package com.cg.exam.dao;

import java.util.ArrayList;

import com.cg.exam.bean.HotelBooking;

public interface IBookingDao {

	
	public ArrayList<HotelBooking> fetchHotelDetails();
	
	
}
