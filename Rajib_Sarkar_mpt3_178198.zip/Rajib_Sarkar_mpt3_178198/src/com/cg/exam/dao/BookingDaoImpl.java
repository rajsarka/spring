package com.cg.exam.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.exam.bean.HotelBooking;

@Repository
@Transactional
public class BookingDaoImpl implements IBookingDao{

	@PersistenceContext
	EntityManager entityMgr=null;
	
	
	public EntityManager getEntityMgr() {
		return entityMgr;
	}


	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}


	

	@Override
	public ArrayList<HotelBooking> fetchHotelDetails() {
		String selQ="SELECT hotels FROM HotelBooking hotels";
		TypedQuery<HotelBooking> tq=entityMgr.createQuery(selQ,HotelBooking.class);
		ArrayList<HotelBooking> tList=(ArrayList)tq.getResultList();
		return tList ;
	}

}
