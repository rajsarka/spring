package com.cg.exam.ctrl;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.exam.bean.HotelBooking;
import com.cg.exam.service.IBookingService;

@Controller

public class BookingController {

	@Autowired
	IBookingService logSer=null;
	
	public IBookingService getLogSer() {
		return logSer;
	}

	public void setLogSer(IBookingService logSer) {
		this.logSer = logSer;
	}

	
	/************************** RETRIEVE ALL Hotel ******************************/
	
	@RequestMapping(value="/ShowHotelBooking")
	public String retrieveAllHotelDetails(Model model)
	{   
		ArrayList<HotelBooking> tList=logSer.fetchHotelDetails();
		model.addAttribute("TraineeListObj", tList);
		return "HotelDetails";
	}
	
	@RequestMapping(value="/HotelBokingSuccessPage")
	public String bookingConfirmation(Model model) {
		HotelBooking hotel = new HotelBooking();
		//hotel=logSer.fetchHotelDetails();
		String msg="Your Rooms are booked at "+hotel.getHotelName();
		model.addAttribute("MsgObj",msg);
		return "BookingConfirmation";
		
	}
	
}
