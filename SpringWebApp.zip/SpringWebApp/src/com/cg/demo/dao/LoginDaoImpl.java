package com.cg.demo.dao;

import org.springframework.stereotype.Repository;

import com.cg.demo.dto.Login;

@Repository
public class LoginDaoImpl implements ILoginDao
{

	@Override
	public Login validtaeUser(Login user) 
	{
		String un=user.getUsername();
		String pw=user.getPassword();
		
		if(un.equalsIgnoreCase("cg")&&pw.equalsIgnoreCase("cg"))
		{
			return user;
		}
		else 
		{
			return null;
		}
		
	}

}
