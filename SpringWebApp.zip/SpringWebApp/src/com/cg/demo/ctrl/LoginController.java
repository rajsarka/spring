package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.demo.dto.Login;
import com.cg.demo.service.ILoginService;


@Controller
public class LoginController {

	@Autowired
	ILoginService logSer=null;
	
	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}
	
	
	/******************/
	
	
	@RequestMapping(value="/LogInPage" ,method=RequestMethod.GET)
	public String showLoginPage(Model model)
	{
		Login lg=new Login();
		String msg="Today is : "+LocalDate.now();
		model.addAttribute("msgobj",msg);
		model.addAttribute("loginobj",lg);  //model attribute "loginobj" name must be in modelattribute on LogIn.jsp
		return "LogIn";  //returning to LogIn.jsp
		
	}
	
	/******************/
	
	
	
	
	@RequestMapping(value="/validtaeUser",method=RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginobj")Login lgg) {
		
		Login user=logSer.validtaeUser(lgg);
		if(user!=null)
		{
  			return "Success";
		}
		else
		{
			return "Failure";
		}
	
		
	}


	
}
