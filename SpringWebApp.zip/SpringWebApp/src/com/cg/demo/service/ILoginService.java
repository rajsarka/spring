package com.cg.demo.service;

import com.cg.demo.dto.Login;

public interface ILoginService 
{
	public Login validtaeUser(Login user);
}
