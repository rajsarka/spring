package com.cg.demo.dao;

import java.util.ArrayList;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Trainee;

public interface ILoginDao 
{

	public Login validtaeUser(Login user);
	public Trainee addAllTrainees(Trainee trn);
	public void delaTrainne(int id);
	public Trainee fetchAUser(int id) ;
	public ArrayList<Trainee> fetchAllUser() ;
	public Trainee modifyUserby(int id,String name,String location,String domain);
}
