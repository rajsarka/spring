package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.demo.dto.Login;

import com.cg.demo.dto.Trainee;

@Repository
@Transactional
public class LoginDaoImpl implements ILoginDao
{
	
	
	@PersistenceContext
	EntityManager entitymgr=null;
	


	public EntityManager getEntitymgr() {
		return entitymgr;
	}
	public void setEntitymgr(EntityManager entitymgr) {
		this.entitymgr = entitymgr;
	}

	
	@Override
	public Login validtaeUser(Login user) 
	{
		
		Login usr =	entitymgr.find(Login.class, user.getUsername()); //retrieving data i.e user name from database
			
		return usr;
	}
	@Override
	public Trainee addAllTrainees(Trainee trn) {
		
		entitymgr.persist(trn);
		Trainee obj=entitymgr.find(Trainee.class, trn.getTraineeId());
		return obj;
		
	}
	public void delaTrainne(int id) {
		Trainee trn=entitymgr.find(Trainee.class, id);
	
		entitymgr.remove(trn);
		
		System.out.println("data deleted....");
		
	}
	public Trainee fetchAUser(int id) {
		
		Trainee obj=entitymgr.find(Trainee.class, id);
		return obj;
	}
	public ArrayList<Trainee> fetchAllUser() 
	{
		String selq="SELECT reg FROM Trainee reg";
		TypedQuery<Trainee> tq=entitymgr.createQuery(selq,Trainee.class);
		ArrayList<Trainee> uList=(ArrayList)tq.getResultList();
		
		return uList;
	}
	public Trainee modifyUserby(int id,String name,String location,String domain) {
		Trainee tran=entitymgr.find(Trainee.class,id);
		tran.setTraineeId(id);
		tran.setTraineeName(name);
		tran.setTraineeDomain(domain);
		tran.setTraineeLocation(location);
		entitymgr.merge(tran);
		
		return tran;
		
	}
}
