package com.cg.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.ILoginDao;
import com.cg.demo.dto.Login;
import com.cg.demo.dto.Trainee;

@Service
public class LoginServiceImpl implements ILoginService 
{
	@Autowired
	ILoginDao loginDao=null;
	
	public ILoginDao getLoginDao()
	{
		return loginDao;
	}
	public void setLoginDao(ILoginDao loginDao)
	{
		this.loginDao=loginDao;
	}
	@Override
	public Trainee addAllTrainees(Trainee trn) {
		
		return loginDao.addAllTrainees(trn);
	}
	@Override
	public Login validtaeUser(Login user) {
		
		return loginDao.validtaeUser(user);
	}
	@Override
	public void delaTrainne(int id) {
		
		loginDao.delaTrainne(id);
		
	}
	@Override
	public Trainee fetchAUser(int id)  {
		return loginDao.fetchAUser(id);
	}
	public ArrayList<Trainee> fetchAllUser() {
		return loginDao.fetchAllUser();
	}
	@Override
	public Trainee modifyUserby(int id, String name, String location, String domain) {
		
		return loginDao.modifyUserby(id, name, location, domain);
	}
}
