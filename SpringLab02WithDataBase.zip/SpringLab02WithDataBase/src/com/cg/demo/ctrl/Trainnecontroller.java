package com.cg.demo.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.demo.dto.Login;

import com.cg.demo.dto.Trainee;
import com.cg.demo.service.ILoginService;
@Controller
public class Trainnecontroller {
	
	/******************Service Object creation**********************/

	@Autowired
	ILoginService logSer=null;
	
	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}
	
	/******************ADD Trainne To table**********************/
	
	@RequestMapping(value="/ShowTrainees")
	public String showAllTrainee(@ModelAttribute("traineeobj")Trainee trn,Model model)
	{
		Trainee tr=new Trainee();
		ArrayList<String> trnList=new ArrayList<String>();
		trnList.add("JAVA");
		trnList.add("Dot Net");
		trnList.add("Oracle");
		trnList.add("Salesforce");
		model.addAttribute("cList",trnList);
		model.addAttribute("showtraineeobj",tr);
		return "AddTrainee";
		
	}
	
	@RequestMapping(value="/addAllUser")
	public String addAllTrainees(@ModelAttribute("traineeobj")Trainee trn,Model model) 
	{
		
		model.addAttribute("traindataobj",trn);
		logSer.addAllTrainees(trn);
		return "disp1";
		
		
	}
	
	
	/******************Delete one trainee by Id************************/
	
	@RequestMapping(value="/deleteTraineebyid")
	public String delTrainee(@RequestParam("unm")int id)
	{
		
		logSer.delaTrainne(id);
		return "disp2";
		
		
	}
	
	@RequestMapping(value="/deleteTrainee")
	public String DeleteTrainee(Model model)
	{
		Trainee tr=new Trainee();
		model.addAttribute("showtraineeobj",tr);
		return "DeleteTrainee";
	}
	
	
	

	
	@RequestMapping(value="/DeleteUser")
	public String dispAUser(@ModelAttribute("showtraineeobj")Trainee trn,Model model)
	{
		
		Trainee trg=logSer.fetchAUser(trn.getTraineeId());
		model.addAttribute("UserListObj",trg);
		return "fetchatrainee";
		
		
	}
	
	/*************Retrieve one trainee by id********/
	
	@RequestMapping(value="/retrTrainee")
	public String retriveTrainee(@ModelAttribute("retrtraineeobj")Trainee trn,Model model)
	{
		Trainee trg=logSer.fetchAUser(trn.getTraineeId());
		model.addAttribute("trnListObj",trg);
		
		return "RetTrainee";
		
	}
	
	@RequestMapping(value="/retrieveaTrainee")
	public String retrTraineepage(Model model)
	{
		Trainee tr=new Trainee();
		model.addAttribute("retrtraineeobj",tr);
		return "ret1";
	}
	/********************************************/
	

	

	
	
	@RequestMapping(value="/retrieveallTrainee")
	public String dispAllUserDetails(Model model)
	{
		ArrayList<Trainee> uList=logSer.fetchAllUser();
		model.addAttribute("UserListObj",uList);
		return "RetAllTrainee";
		
		
	}
	
	/************************/
	
	@RequestMapping(value="/modifyref")
	public String modiTrainee(Model model)
	{
		Trainee trn=new Trainee();
		model.addAttribute("modObj",trn);
		return "Modify";
		
	}
	@RequestMapping(value="/aftermodify")
	public String modifyafter(@ModelAttribute("modObj")Trainee trn,Model model)
	{
		
		Trainee modtr=logSer.fetchAUser(trn.getTraineeId());
		model.addAttribute("modiObj",modtr);
		return "ModTrainee";
		
		
	}
	
	@RequestMapping(value="/modifyinput")
	public String modinput(@ModelAttribute("modiObj")Trainee trn,Model model)
	{
		int i=trn.getTraineeId();
		String n=trn.getTraineeName();
		String l=trn.getTraineeLocation();
		String d=trn.getTraineeDomain();
		logSer.modifyUserby(i,n,l,d);
		model.addAttribute("modObj",trn);
		
		return "Modify";
		
	}
	
	
	
	/**************************************/
	

	
	

	
	
	
	
	
	
	
	
	
	
	

	
		
		
}	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	


