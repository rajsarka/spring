package com.cg.spring.lab1a;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Test1a {

	public static void main(String[] args) {
		
		ApplicationContext ctx= new  ClassPathXmlApplicationContext("cg.xml");
		Employee e1=(Employee) ctx.getBean("emp1");
		System.out.println(e1);
		
		
		
		
		
		
		
		
		
		
	}

}
