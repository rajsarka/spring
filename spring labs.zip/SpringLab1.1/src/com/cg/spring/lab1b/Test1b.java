package com.cg.spring.lab1b;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Test1b {

	public static void main(String[] args) {
		
		ApplicationContext ctx= new  ClassPathXmlApplicationContext("cg.xml");
		/*Employee e1=(Employee) ctx.getBean("emp1");
		System.out.println("Employee Details");
		System.out.println("-----------------");
		System.out.println("Employee ID: "+e1.getEmployeeId());
		System.out.println("Employee Name: "+e1.getEmployeeName());
		System.out.println("Employee Salary: "+e1.getSalary());
		System.out.println("Employee BU: "+e1.getBusinessUnit());
		System.out.println("Employee Age: "+e1.getAge());*/
		
		
		Employee e2=(Employee) ctx.getBean("emp2");
		System.out.println("Employee Details");
		System.out.println("-----------------");
		System.out.println("Employee ID: "+e2.getEmployeeId());
		System.out.println("Employee Name: "+e2.getEmployeeName());
		System.out.println("Employee Salary: "+e2.getSalary());
		System.out.println("Employee BU: "+e2.getBusinessUnit());
		System.out.println("Employee Age: "+e2.getAge());
		
		
		
		
		
		
		
	}

}
