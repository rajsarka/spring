package com.cg.spring.lab1a;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Test1a {

	public static void main(String[] args) {
		
		ApplicationContext ctx= new  ClassPathXmlApplicationContext("cg.xml");
		SBU e1=(SBU) ctx.getBean("sbu1");
		System.out.println("SBU Details-----");
		System.out.println("SBUCode= "+e1.getSbuId()+", SBUHead= "+e1.getSbuHead()+", SBUName= "+e1.getSbuName());
		System.out.println("Employee Details-----");
		System.out.println(e1.getEmpList());
		/*Employee e2=(Employee) ctx.getBean("emp1");
		System.out.println("Employee Details-----");
		System.out.println(e2);*/
		
		
		
		
		
		
		
		
		
	}

}
