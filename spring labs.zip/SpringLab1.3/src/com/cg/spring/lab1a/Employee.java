package com.cg.spring.lab1a;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



public class Employee {
	private int employeeId;
	private String employeeName;
	private int Salary;
	private String BusinessUnit;
	private int age;
	
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public String getBusinessUnit() {
		return BusinessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		BusinessUnit = businessUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", Salary=" + Salary
				+ ", BusinessUnit=" + BusinessUnit + ", age=" + age + "]";
	}
	public Employee() {
		
	}
	public Employee(int employeeId, String employeeName, int salary, String businessUnit, int age) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		Salary = salary;
		BusinessUnit = businessUnit;
		this.age = age;
		
	}
	
	
	
	
}
