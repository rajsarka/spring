package com.cg.demo.dao;



public interface ITraineeDao {

	
	
	
	
}
