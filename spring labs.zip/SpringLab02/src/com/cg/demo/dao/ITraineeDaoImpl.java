package com.cg.demo.dao;

public class ITraineeDaoImpl implements ITraineeDao{

}
