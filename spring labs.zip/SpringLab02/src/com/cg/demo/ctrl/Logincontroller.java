package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
@RequestMapping("/loginCtrl")
public class Logincontroller {

	@Controller
	public class LoginController {

		@RequestMapping(value="/ShowLoginpage")
		public String dispLoginPage(Model model)
		{
			String today="Today is: "+LocalDate.now();
			model.addAttribute("todayObj",today);
			return "LogIn";
			
		}
		
		
		

		
	}

	
}
