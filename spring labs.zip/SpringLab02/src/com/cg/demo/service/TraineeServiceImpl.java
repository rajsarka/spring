package com.cg.demo.service;

public class TraineeServiceImpl implements ITraineeService{

}
