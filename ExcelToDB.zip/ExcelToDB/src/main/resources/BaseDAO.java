
public class BaseDAO {

}
